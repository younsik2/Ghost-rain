
function setLeft(left) {
  const currentLeft = parseInt(getComputedStyle(heroElement).left);
  const newleft = currentLeft + left;

  if (newleft > BG_WIDTH - HERO_WIDTH || newleft < 0) return;

  heroElement.style.left = newleft + "px";
}
