function randomRange(min, max) {
  return Math.floor(Math.random() * (max + 1 - min)) + min;
}

function create() {
  let enemyTop = 0;
  const ghostElement = document.createElement("div");

  ghostElement.style.position = "absolute";
  ghostElement.style.top = enemyTop + "px";
  ghostElement.style.left = randomRange(0, BG_WIDTH - GHOST_WIDTH) + "px";

  ghostElement.style.width = GHOST_WIDTH + "px";
  ghostElement.style.height = GHOST_HEIGHT + "px";
  ghostElement.style.background = 'url("./images/ghost.png") no-repeat';

  bg.append(ghostElement);

  window.requestAnimationFrame(function () {
    move(enemyTop, ghostElement);
  });
}

function move(top, el) {
  top++;
  const ghostLeft = parseInt(el.style.left);
  const heroLeft = parseInt(heroElement.style.left);


  if (top > BG_HEIGHT - (HERO_HEIGHT + GHOST_HEIGHT)) {

    if (
      heroLeft < ghostLeft + GHOST_WIDTH && 
      heroLeft + HERO_WIDTH > ghostLeft 
    ) {
      die(el);
      return;
    }
    if (top > BG_HEIGHT - GHOST_HEIGHT) {
      remove(el);
      return;
    }
  }
  el.style.top = top + "px";

  window.requestAnimationFrame(function () {
    move(top, el);
  });
}


function remove(ghostElement) {
  ghostElement.remove();
  life -= 1;
  if (life === 4) lifeDisplay.innerHTML = "❤❤❤❤";
  else if (life === 3) lifeDisplay.innerHTML = "❤❤❤";
  else if (life === 2) lifeDisplay.innerHTML = "❤❤";
  else if (life === 1) lifeDisplay.innerHTML = "❤";
  else if (life === 0) lifeDisplay.innerHTML = "GAME OVER";
  return;
}

function die(ghostElement) {
  ghostElement.style.backgroundPosition = "-45px";

  const soundEffect = new Audio("./audio/dying.wav");
  soundEffect.play();

  score += 1;
  scoreDisplay.innerHTML = score;

  setTimeout(() => {
    ghostElement.remove();
  }, 3000);
}
