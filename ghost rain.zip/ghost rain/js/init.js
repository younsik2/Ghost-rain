function init() {
  heroElement.style.display = "inline-block";
  document.addEventListener(
    'keydown',
    function (e) {
      checkKey(e, true);
    },
    false
  );

  document.addEventListener(
    "keyup",
    function (e) {
      checkKey(e, false);
    },
    false
  );

  setInterval(function () {
    create();
  }, 2000);
}


function TIMER(){
  PlAYTIME=setInterval(function(){
      time=time-1000; //1초씩 줄어듦
      min=time/(60*1000); //초를 분으로 나눠준다.

     if(sec>0){ //sec=60 에서 1씩 빼서 출력해준다.
          sec=sec-1;
          Timer.value=Math.floor(min)+':'+sec; //실수로 계산되기 때문에 소숫점 아래를 버리고 출력해준다.

      }
      if(sec===0){
         // 0에서 -1을 하면 -59가 출력된다.
          // 그래서 0이 되면 바로 sec을 60으로 돌려주고 value에는 0을 출력하도록 해준다.
          sec=60;
          Timer.value=Math.floor(min)+':'+'00'
      }     
  },1000); //1초마다 
}


TIMER();
setTimeout(function(){
  clearInterval(PlAYTIME);
},60000);//3분이 되면 타이머를 삭제한다.
;
function checkKey(e, isMoving) {
  if (isMoving) {
    //keyCode와 which 모두 키 코드
    const keyID = e.keyCode || e.which;

    switch (keyID) {
      case 39: //right
        heroElement.className = "right";
        // setLeft는 인자값만큼 영웅을 이동시키는 함수
        setLeft(10);
        // preventDefault를 넣어줌으로써, 좌 우 방향키를 눌러도 페이지가 이동하지 않음
        e.preventDefault();
        break;
      case 37: //left
        heroElement.className = "left";
        setLeft(-10);
        e.preventDefault();
        break;
      case 38: //top
        heroElement.className = 'Top';
        setLeft(-100);
        e.preventDefault();
        break;
      case 40: //down
        heroElement.className = 'down';
        setLeft(100);
        e.preventDefault();
        break;
    }
  } else {
    heroElement.className = "stop";
  }
}

heroElement.style.display = "none";
start.addEventListener("click", init);
Timer.addEventListener("click", init);